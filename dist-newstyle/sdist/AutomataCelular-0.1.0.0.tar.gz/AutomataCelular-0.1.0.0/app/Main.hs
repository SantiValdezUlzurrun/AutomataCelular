module Main where

import Graphics.Gloss
import Graphics.Gloss.Data.Picture

import Regla110

main :: IO ()
main = mainRegla110
