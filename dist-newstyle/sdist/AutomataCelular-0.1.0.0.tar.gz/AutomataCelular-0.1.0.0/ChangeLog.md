# Changelog for AutomataCelular

## Unreleased changes
